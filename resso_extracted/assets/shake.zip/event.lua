local nowCount = -1
local init_count = 2
local geFeaturePath = "PutFrame/"
local max_offset = 6
local period = 2 * math.pi
local rightMargin = 20/360.0

function print_line(this, effectManager, text2d, ge, time, srt_line, curIndex)
    if curIndex ~= nowCount or init_count > 0 then
        local text_layout = EffectSdk.BEFTextLayoutParam()
        text_layout.fontSize = 128.0 * effectManager:getInputWidth() / 720.0
        text_layout.letterSpacing = 0
        text_layout.lineWidth = 600.0 * effectManager:getInputWidth() / 720.0
        text_layout.lineSpacingMult  = 1
        text_layout.textAlign = 1
        text_layout.maxLine = 0
        text_layout.fontPath = text2d:getRootDir()
        text_layout.familyName = "BOXING.otf"
        text_layout.fontStyle = 0
        text_layout.lineBreakMode = 0
        text_layout.textColor = 0
        text_layout.backColor = 0
        text_layout.strokeWidth = 0
        text2d:generateBitmapUTF32("display_texture", srt_line:text(), srt_line:length(), text_layout, EffectSdk.TEXT_BITMAP_SHAKE_ALPHA)
        nowCount = curIndex  
        init_count = init_count - 1          
    end
    local duration = srt_line:endTime() - srt_line:startTime()
    local progress = time - srt_line:startTime()
    local charLayoutArray = text2d:getTextLayoutWithKey("display_texture")
    if charLayoutArray == nil then
        return
    end
    local count = charLayoutArray:getCount()
    local lineDuration = duration / count
    local rowIndex = math.floor(progress / lineDuration)

    local lineProgress = progress - rowIndex * lineDuration
  
    local rectf = effectManager:getRenderCacheSize("display_texture")
    local displayWidth = effectManager:getInputWidth()
    local displayHeight = effectManager:getInputHeight()
    local textureWidth = rectf.right * displayWidth
    local textureHeight = rectf.bottom * displayHeight

    local counter = 0

    local mode = 4
    local vertexStep = 3
    local uvStep = 2
    local vertexList = EffectSdk.vectorp3()
    local uvList = EffectSdk.vectorp3()
    local indexList = EffectSdk.vectori()
    local colorAttList = EffectSdk.vectorf()

    local topCharLayout = charLayoutArray:getCharLayout(0)
    local duration = srt_line:endTime() - srt_line:startTime()
    local progress = time - srt_line:startTime()
    local startIndex = math.floor(rowIndex / 4) * 4
    local endIndex = rowIndex

	local verticalOffset = (effectManager:getInputHeight() - effectManager:getInputWidth() * 16.0 /9.0) / 2.0 / effectManager:getInputHeight() + 84.0 * 2.0 / effectManager:getInputHeight()
  
    for index=startIndex,endIndex do
        local charLayout = charLayoutArray:getCharLayout(index)
        local startCharLayout = charLayoutArray:getCharLayout(startIndex)
        if charLayout == nil or startCharLayout == nil then
            return
        end
        local line_uv_width = charLayout.texture_right - charLayout.texture_left
        local line_uv_height = charLayout.texture_bottom - charLayout.texture_top

        local offsetY = textureHeight * (startCharLayout.texture_top - topCharLayout.texture_top) / displayHeight
        local top_offset = textureHeight * (charLayout.texture_top - topCharLayout.texture_top) / displayHeight
        local line_width = textureWidth * line_uv_width / displayWidth
        local line_height = textureHeight * line_uv_height / displayHeight
        local positionTop = top_offset - offsetY + verticalOffset 
        local positionBottom = line_height + top_offset - offsetY + verticalOffset

        local animation = (index == endIndex) and 1.0 or 0.0

		
		
        local position1 = EffectSdk.Vec3(1.0 - rightMargin - line_width, positionTop, animation)
        vertexList:push_back(position1)
        local position2 = EffectSdk.Vec3(1.0 - rightMargin - line_width, positionBottom, animation)
        vertexList:push_back(position2)

        local position3 = EffectSdk.Vec3(1.0 - rightMargin, positionTop, animation)
        vertexList:push_back(position3)
        local position4 = EffectSdk.Vec3(1.0 - rightMargin, positionBottom, animation)
        vertexList:push_back(position4)

        local leftPadding = 10 / 360.0
        local rightPadding = 10 / 360.0
        local uv1 = EffectSdk.Vec3(charLayout.texture_left - leftPadding, charLayout.texture_top, 0.0)
        uvList:push_back(uv1)
        local uv2 = EffectSdk.Vec3(charLayout.texture_left - leftPadding, charLayout.texture_bottom, 0.0)
        uvList:push_back(uv2)
        local uv3 = EffectSdk.Vec3(charLayout.texture_right + rightPadding, charLayout.texture_top, 0.0)
        uvList:push_back(uv3)
        local uv4 = EffectSdk.Vec3(charLayout.texture_right + rightPadding, charLayout.texture_bottom, 0.0)
        uvList:push_back(uv4)

        indexList:push_back(counter * 4 + 0)
        indexList:push_back(counter * 4 + 1)
        indexList:push_back(counter * 4 + 2)
        indexList:push_back(counter * 4 + 1)
        indexList:push_back(counter * 4 + 3)
        indexList:push_back(counter * 4 + 2)

        ge:setBrcData("text1", mode, vertexList, vertexStep, uvList, uvStep, indexList)
        counter = counter + 1
    end

    local startTime = srt_line:startTime()
    local endTime = srt_line:endTime()

    ge:setUniformFloat("text1", 1, "u_startTime", startTime)
    ge:setUniformFloat("text1", 1, "u_endTime", endTime)
    ge:setUniformFloat("text1", 1, "u_currentTime", time) 

    local scaledTime = time * 5.0
    local offset = (math.sin(scaledTime) + math.sin(scaledTime * 5) + math.sin(scaledTime * 7) + math.sin(scaledTime * 9)) / 4.0
    
    -- ge:setUniformVec2("text1", 1, "u_pos", 0.083, 0.22)
     -- ge:setUniformVec2("text1", 1, "u_pos", 0.0, 84.0/640) 
    ge:setUniformVec2("text1", 1, "u_pos", 0.0, 0.0) 
    ge:setUniformFloat("text1", 1, "u_xoff", max_offset * (math.abs(offset)))
end

function find_srt(srt_data, time)
    local count = srt_data:count()
    for i = 0, count - 1 do
        local srt_line = srt_data:data(i)
        if srt_line:endTime() >= time and srt_line:startTime() <= time then
            return i
        end
    end
    return -1
end

EventHandles =
{
    handleEffectEvent = function (this, eventCode)
        this:addTimer( 3214349, EffectSdk.BEF_TIMER_EVENT_CIRCLE, 10)
        return true
    end,
    handleTimerEvent = function (this, timerId, milliSeconds)
        local feature = this:getFeature("text")
        if not feature then
            return
        end
        local text2d = EffectSdk.castText2DV2Feature(feature)
        local feature2 = this:getFeature(geFeaturePath)
        if not feature2 then
            return
        end
        local ge = EffectSdk.castGeneralEffectFeature(feature2)

        local effectManager = this:getEffectManager()
        if not effectManager then
            return
        end
        local time = effectManager:getMusicCurrentTime()

        if effectManager:getSRTStatus() then
            effectManager:swapSRTIndex()
        end
        local srt_data = effectManager:getSRTData()
        if srt_data == nil then
            return
        end

        local index = find_srt(srt_data, time)
        if index ~= -1 then
            local srt_line = srt_data:data(index)
            print_line(this, effectManager, text2d, ge, time, srt_line, index)
        end       
        return true
    end
}

