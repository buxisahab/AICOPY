precision highp float;

attribute vec3 attPosition;
attribute vec2 attUV;

uniform int u_width;

uniform vec2 u_pos;
uniform float u_xoff;

varying highp vec2 textureCoordinate;
varying highp vec2 offset;
varying float shake;

void main() {
    vec2 pos = u_pos + attPosition.xy;
    gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);
    textureCoordinate = attUV.xy;
    
    offset = vec2(u_xoff / float(u_width) * 2.0, 0.0);
    shake = attPosition.z;
}


