precision highp float;

uniform sampler2D u_text;

varying highp vec2 textureCoordinate;
varying highp vec2 offset;
varying float shake;

uniform float u_startTime;
uniform float u_endTime;
uniform float u_currentTime;

void main() {
    float current = u_currentTime - u_startTime;
    float total = u_endTime - u_startTime;
    float alphaMulitiplier = 1.0;
    float intensity;
    if (current < total / 40.0) {
        intensity = 3.0 * current / total;
    }
    else if (current < total * 39.0 / 40.0) {
        intensity = 1.0;
    }
    else {
        intensity = 3.0 * (u_endTime - u_currentTime) / total;
    }
    
    float alpha = texture2D(u_text, textureCoordinate).a;
    if (shake == 0.0) {
        gl_FragColor =  vec4(alpha, alpha, alpha, alpha);
        return;
    }
    vec2 rOffset = vec2(10.0/720.0, 0.0) + offset;
    vec2 gOffset = vec2(0.0/720.0, 0.0);
    vec2 bOffset = vec2(-10.0/720.0, 0.0) - offset;
    float alpha1 = texture2D(u_text, textureCoordinate + rOffset).a * alphaMulitiplier;
    float alpha2 = texture2D(u_text, textureCoordinate + gOffset).a * alphaMulitiplier;
    float alpha3 = texture2D(u_text, textureCoordinate + bOffset).a * alphaMulitiplier;
    
    vec4 color = vec4(alpha1, 0.0, 0.0, alpha1);
    color += vec4(0.0, alpha2, 0.0, alpha2);
    color += vec4(0.0, 0.0, alpha3, alpha3);
    
    color = min(vec4(1.0), color);
    gl_FragColor = color * intensity;
}



