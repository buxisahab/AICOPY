precision highp float;

attribute vec3 attPosition;
attribute vec2 attUV;

uniform int u_width;
uniform int u_height;
uniform int u_width2;
uniform int u_height2;
uniform int u_width3;
uniform int u_height3;
uniform float u_d_width_offset;
uniform float u_d_height_offset;
uniform vec2 u_pos;
uniform float u_intensity;

varying highp vec2 textureCoordinate;
varying highp float alpha;

void main() {
    float scale = 1.0 - 0.333333 * u_intensity;
    float scale2 = 0.666667 + 0.333333 * u_intensity;
    float scale3 = 0.666667;
    alpha = 1.0 - u_intensity;

    vec2 weight = vec2(float(u_width) * u_d_width_offset, float(u_height) * u_d_height_offset);
    vec2 pos1 = u_pos + 0.5 * (attPosition.xy + 1.0) * weight * scale;
    vec2 pos2 = u_pos + 0.5 * (attPosition.xy + 1.0) * weight * scale;
    pos2.y = pos2.y - 0.03125 - float(u_height) * u_d_height_offset * scale;
    vec2 pos = pos1 * (1.0 - u_intensity) + u_intensity * pos2;

    gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);
    textureCoordinate = attUV.xy;
}

