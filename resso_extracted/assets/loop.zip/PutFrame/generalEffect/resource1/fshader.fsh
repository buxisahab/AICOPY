precision highp float;

uniform sampler2D u_text;

varying highp vec2 textureCoordinate;
varying highp float alpha;

void main() {
    float mask = texture2D(u_text, textureCoordinate).a;
    vec4 color = vec4(mask, mask, mask, mask) * alpha;
    gl_FragColor = color;
}

