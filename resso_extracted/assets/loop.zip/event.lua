local initFlag = false
local lastId = -1
local init_count = 2
local nextId_1 = -1
local nextId_2 = -1
function find_srt(srt_data, time)
    local count = srt_data:count()
    for i = 0, count - 1 do
        local srt_line = srt_data:data(i)
        if srt_line:endTime() >= time and srt_line:startTime() <= time then
            return i
        end
    end
    return -1
end

function add_texture(this, text2d, srt_line)
    local effectManager = this:getEffectManager()
    if not effectManager then
        return
    end
    local inputWidth = effectManager:getInputWidth()
    local inputHeight = effectManager:getInputHeight()
    text2d:pushCommandMove("display_texture2", "display_texture")
    text2d:pushCommandMove("display_texture3", "display_texture2")
    text2d:pushCommandRemove("display_texture3")
    if srt_line then
        text2d:pushCommandGenerate("display_texture3", srt_line:text(), srt_line:length(), 
            56 / inputHeight, 0, 630 / inputWidth, 1.0, 0, 0, 1)
    end
end

local split_time = 0.2
local swap_flag = false
local init_flag = true

function handleEvent(this)
    local feature = this:getFeature("text")
    if not feature then
        return
    end
    local text2d = EffectSdk.castText2DFeature(feature)

    local effectManager = this:getEffectManager()
    if not effectManager then
        return
    end
    local time = effectManager:getMusicCurrentTime()
    local srt_data = effectManager:getSRTData()
    local inputWidth = effectManager:getInputWidth()
    local inputHeight = effectManager:getInputHeight()
    if effectManager:getFontStatus() then
        text2d:updateFontPath()
    end
    
    if effectManager:getSRTStatus() then
        effectManager:swapSRTIndex()
        nextId_1 = -1
        nextId_2 = -1
    end

    -- 0.05, 0.12
    -- 0.05, 0.113
    -- 0.05, 0.1
    local cc = 1.25
    local yOffset1 = (0.12 * 1280 * cc + (inputHeight - 1280) / 2.0) / inputHeight
    local yOffset2 = (0.113 * 1280 * cc + (inputHeight - 1280) / 2.0) / inputHeight
    local yOffset3 = (0.1 * 1280 * cc + (inputHeight - 1280) / 2.0) / inputHeight


    local id = find_srt(srt_data, time)
    if id ~= -1 then
        local srt_line = srt_data:data(id)
        local startTime = srt_line:startTime()
        local endTime = srt_line:endTime()

        local intensity = 1.0
        local used_split_time = split_time

        if lastId ~= id or init_count > 0 then
            if id == 0 then
                text2d:pushCommandRemove("display_texture")
            end

            if (id ~= nextId_1) then
                text2d:pushCommandGenerate("display_texture2", srt_line:text(), srt_line:length(), 
                56 / inputHeight, 0, 630 / inputWidth, 1.0, 0, 0, 1)
                nextId_1 = -1
            end

            if id < srt_data:count() - 1 then
                if ((id+1) ~= nextId_2) then
                    local srt_line2 = srt_data:data(id + 1)
                    text2d:pushCommandGenerate("display_texture3", srt_line2:text(), srt_line2:length(), 
                        56 / inputHeight, 0, 630 / inputWidth, 1.0, 0, 0, 1)   
                    nextId_2 = -1
                end
                nextId_1 = id + 1
            else
                nextId_1 = -1
                nextId_2 = -1
            end
            lastId = id
            init_count = init_count - 1
        end


        if endTime - startTime < 2 * split_time then
            used_split_time = (endTime - startTime) / 2.0
        end
        if startTime > time - used_split_time then
            intensity = 0.5 + (time - startTime) / used_split_time / 2.0
            swap_flag = false
        elseif endTime < time + used_split_time then
            intensity = (time + used_split_time - endTime) / used_split_time / 2.0
            if not swap_flag then
                swap_flag = true
                -- swap texture
                if id < srt_data:count() - 2 then
                    add_texture(this, text2d, srt_data:data(id + 2))
                    nextId_2 = id + 2
                else
                    add_texture(this, text2d, nil)
                    nextId_2 = -1
                end
            end
        else
            swap_flag = false
        end

        local feature = this:getFeature("PutFrame/")
        if not feature then
            return
        end
        local ge = EffectSdk.castGeneralEffectFeature(feature)

        local feature2 = this:getFeature("PutFrame2/")
        if not feature2 then
            return
        end
        local ge2 = EffectSdk.castGeneralEffectFeature(feature2)

        local feature3 = this:getFeature("PutFrame3/")
        if not feature3 then
            return
        end
        local ge3 = EffectSdk.castGeneralEffectFeature(feature3)

        ge:setUniformFloat("text1", 1, "u_intensity", intensity)
        ge:setUniformVec2("text1", 1, "u_pos", 0.045, yOffset1)
        ge2:setUniformFloat("text2", 1, "u_intensity", intensity)
        ge2:setUniformVec2("text2", 1, "u_pos", 0.045, yOffset2)
        ge3:setUniformFloat("text3", 1, "u_intensity", intensity)
        ge3:setUniformVec2("text3", 1, "u_pos", 0.045, yOffset3)
        -- print(intensity)
        lastId = id
    else

    end

end

EventHandles =
{
    handleEffectEvent = function (this, eventCode)
        if (initFlag) then
            return true
        end
        initFlag = true
        
        handleEvent(this)
        
        this:addTimer( 3214349, EffectSdk.BEF_TIMER_EVENT_CIRCLE, 10)

        local feature = this:getFeature("text")
        local text2d = EffectSdk.castText2DFeature(feature)
        text2d:updateFontPath()
        
        return true
    end,
    handleTimerEvent = function (this, timerId, milliSeconds)
        handleEvent(this)
        return true
    end
}
