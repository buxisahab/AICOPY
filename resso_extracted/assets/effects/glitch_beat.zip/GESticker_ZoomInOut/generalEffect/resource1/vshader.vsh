precision highp float;

attribute vec3 attPosition;
attribute vec2 attUV;
uniform float amplitude;

varying vec2 textureCoordinate;

void main() {
    gl_Position = vec4(attPosition.x * amplitude, attPosition.y * amplitude, attPosition.z, 1.0);
    //gl_Position = vec4(attPosition.x * 2.0, attPosition.y * 2.0, attPosition.z, 1.0);

    // gl_Position = vec4(attPosition,1.0);
    textureCoordinate = attUV.xy;
}
