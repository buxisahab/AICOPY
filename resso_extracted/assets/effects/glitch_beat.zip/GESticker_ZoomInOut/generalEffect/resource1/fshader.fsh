precision highp float;

varying highp vec2 textureCoordinate;

uniform sampler2D inputImageTexture;
uniform highp float scalePercent;

uniform float time;

uniform float hasGlitch;

highp vec3 W = vec3(0.2125, 0.7154, 0.0721);

float random (vec2 st) {
    highp float a = 12.9898;
    highp float b = 78.233;
    highp float c = 43758.5453;
    highp float dt= dot(st.xy ,vec2(a,b));
    highp float sn= mod(dt,3.14);
    return fract(sin(sn) * c);
}

float randomRange (vec2 standard ,float min, float max) {
    return min + random(standard) * (max - min);
}

vec4 getGrayScaleColor(sampler2D texture, vec2 uv) {
    vec4 color = texture2D(texture, uv);
    return vec4(vec3(dot(color.rgb, W)), 1.0);
}

vec4 blendColor(vec4 color, vec4 shiftColor1, vec4 shiftColor2) {
  vec4 blendColor = vec4(shiftColor2.r, 0.0, 0.0, 1.0);
  blendColor += vec4(0.0, color.g, 0.0, 1.0);
  blendColor += vec4(0.0, 0.0, shiftColor1.b, 1.0);
       
  blendColor = min(vec4(1.0), blendColor);
  return blendColor;
}

void main() {
    vec4 grayScaleColor = getGrayScaleColor(inputImageTexture, textureCoordinate);
    float normalizedScale = 0.1 * (scalePercent - 1.0);
       
    vec4 shiftColorGrayScale1 = getGrayScaleColor(inputImageTexture, textureCoordinate + vec2(normalizedScale,0));
    vec4 shiftColorGrayScale2 = getGrayScaleColor(inputImageTexture, textureCoordinate + vec2(-normalizedScale,0));
       
    vec4 color = blendColor(grayScaleColor, shiftColorGrayScale2, shiftColorGrayScale1);
    
    if (abs(hasGlitch - 1.0) < 0.1) {
        float offset = 0.1;
        float speed = 0.15;
        float cTime = floor(time * speed * 50.0);
        float maxSplitOffset = offset / 3.0;
        for (int i = 0; i < 10; i += 1) {
            float sliceY = random(vec2(cTime + offset, 1999.0 + float(i)));
            float sliceH = random(vec2(cTime + offset, 9999.0 + float(i))) * 0.015;
            float hOffset = randomRange(vec2(cTime + offset, 9625.0 + float(i)), -maxSplitOffset, maxSplitOffset);
            vec2 splitOff = textureCoordinate;
            splitOff.x += hOffset;
            splitOff = fract(splitOff);
            if (textureCoordinate.y > sliceY && textureCoordinate.y < fract(sliceY+sliceH)) {
                // color = vec4(texture2D(inputImageTexture, splitOff).rgb, 1.0);
                color = getGrayScaleColor(inputImageTexture, splitOff);
                vec4 shiftColorGrayScale1 = getGrayScaleColor(inputImageTexture, textureCoordinate + vec2(normalizedScale,0));
                vec4 shiftColorGrayScale2 = getGrayScaleColor(inputImageTexture, textureCoordinate + vec2(-normalizedScale,0));
                color = blendColor(color, shiftColorGrayScale2, shiftColorGrayScale1);
            }
        }
    }
    
    gl_FragColor = color;
}
