math.randomseed(os.time())

local animationType = 0
local SCALE_ANIMATION_DURATION = 0.15
local SCALE_ANIMATION_MAX_AMPLITUTDE = 0.05
local animationStartTime = 0.0
local lastTime = 0.0

local PI = 3.1415926
local level = 0
local RGB_SPLIT_ANIMATION_DURATION = 1.0
local rgbAnimationStartTime = 0.0

local specialEffectLevelThreshold = 5
local initFlag = false
quantiArray = 
{
    1.05,
    1.10,
    1.15,
    1.20,
    1.25, 
    1.30,
    1.35,
    1.40,
    1.50,
    1.6
}
-- quantiArray = 
-- {
--     1.2,
--     1.4,
--     1.8,
--     2.0
-- }

-- @function [parent=#math] clamp
function math.clamp(v, minValue, maxValue)  
    if v < minValue then
        return minValue
    end
    if( v > maxValue) then
        return maxValue
    end
    return v 
end
-- THRES = 0.05
THRES = 50
holdOn = 0
holdOnMax = 5
-- magnitude = 1.0


function animateAmplitude(time)    
    processedTime = math.fmod(time - animationStartTime, SCALE_ANIMATION_DURATION)
   
    -- amplitude [1.0,1.3]
    amplitude = 1.0 + SCALE_ANIMATION_MAX_AMPLITUTDE * math.abs(math.sin(processedTime * (PI / SCALE_ANIMATION_DURATION)))
    return amplitude
end

function rgbOffset(time, maxOffset)
    processedTime = math.fmod(time - rgbAnimationStartTime, RGB_SPLIT_ANIMATION_DURATION)
    return maxOffset * math.abs(math.sin(processedTime * (PI / RGB_SPLIT_ANIMATION_DURATION)))
end

local test = true
EventHandles =
{
    handleEffectEvent = function(this, eventCode)
        if (initFlag) then
            return true
        end
        initFlag = true

        -- Timer
        this:addTimer(3214349, EffectSdk.BEF_TIMER_EVENT_CIRCLE, 10)
        -- EffectSdk.LOG_LEVEL(6, "handleEffectEvent, addTimer")
        return true
    end,
    handleTimerEvent = function(this, timerId, milliSeconds)
        if timerId == 3214349 then
            local effectManager = this:getEffectManager()
            if not effectManager then
                return
            end
            local time = effectManager:getTimeStamp()

            local feature_zoom = this:getFeature("GESticker_ZoomInOut")
            if not feature_zoom then
                return
            end
            local feature_zoomItem = EffectSdk.castGeneralEffectFeature(feature_zoom)
            if feature_zoomItem and animationType == 1 then
                if time < lastTime then
                    local remainder = 0
                    if lastTime > animationStartTime then
                        remainder = lastTime - animationStartTime
                    else
                        remainder = SCALE_ANIMATION_DURATION
                    end
                    local lastAnimationStartTime = animationStartTime
                    animationStartTime = time - remainder
                    -- EffectSdk.LOG_LEVEL(6, "modify, lastAnimationStartTime: " .. lastAnimationStartTime .. ", animationStartTime: " .. animationStartTime .. ", remainder: " .. remainder)
                end

                if time < animationStartTime + SCALE_ANIMATION_DURATION then
                    feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "amplitude", animateAmplitude(time))
                else
                    feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "amplitude", 1.0)
                    animationType = 0
                    animationStartTime = -1
                end
            else
                feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "amplitude", 1.0)
            end

            lastTime = time
        end
    end,
    handleAudioOnsetEvent = function(this, recognize_stmp, recognize_onset)
        -- EffectSdk.LOG_LEVEL(6, "recognize_stmp: " .. recognize_stmp .. ", recognize_onset: " .. recognize_onset)
        local feature_zoom = this:getFeature("GESticker_ZoomInOut")
        local feature_zoomItem = EffectSdk.castGeneralEffectFeature(feature_zoom)
        if not feature_zoomItem then
            -- EffectSdk.LOG_LEVEL(6, "feature_zoomItem is nil")
            return
        end

        if recognize_onset >= THRES then
            local time = recognize_stmp
            level = math.clamp(math.floor(math.abs(recognize_onset) / 100), 1, 10)
            feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "scalePercent", quantiArray[level])

            if animationType == 0 and level >= 4 then
                animationType = 1
                local effectManager = this:getEffectManager()
                if not effectManager then
                    return
                end
                local effectTime = effectManager:getTimeStamp()
                animationStartTime = effectTime
                feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "amplitude", animateAmplitude(effectTime))
            end

            if level >= specialEffectLevelThreshold then
                feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "hasGlitch", 1.0)
            else
                feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "hasGlitch", 0.0)
            end
        else
            feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "scalePercent", 1.0)
            feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "hasGlitch", 0.0)
        end

        feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "time", recognize_stmp)
        feature_zoomItem:setUniformFloat("DizzyZoomInOut", 3, "level", level)
    end
}


