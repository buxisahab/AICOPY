local initFlag = false
local nowCount = -1
local init_count = 2
local geFeaturePath = "PutFrame/"
local ptFontSize = 76
local linesWidth = 560.0
local mTimerId = 67183
local showTime = 0.66
local showTimeShort = 5.0 / 30

local normWidth = 1080.
local normHeight = 1920.
local keyFrameCenterPos = {
    {529.6, 643.1},
    {519.6, 649.1},
    {531.6, 657.1},
    {543.6, 651.1},
    {537.6, 643.1},
    {549.6, 653.1},
    {547.6, 663.1},
    {537.6, 655.1},
    {525.6, 659.1},
    {539.6, 661.1},
    {549.6, 655.1},
    {537.6, 651.1},
    {529.6, 643.1}
}
local keyFrameTime = {0, 0.4, 0.8, 1.2, 1.6, 2, 2.4, 2.8, 3.2, 3.6, 4, 4.4, 4.8}
local totalKeyFrameDuration = 4.8

local fontName = "FloodStd.otf"
math.randomseed(os.time())

function updateStartTime(this)
    local effectManager = this:getEffectManager()
    if effectManager then startTime = effectManager:getTimeStamp() end
    return true
end

function getDuration(this)
    local effectManager = this:getEffectManager()
    if effectManager then
        local ts = effectManager:getTimeStamp()
        local duration = ts - startTime
        return duration
    end
end

function getVal(refMin, refMax, refVal, min, max)
    local ret = (min * (refMax - refVal) + max * (refVal - refMin)) / (refMax - refMin)
    return ret
end

function print_line(this, text2d, ge, srt_data, time)
    local effectManager = this:getEffectManager()
    local inputHeight = effectManager:getInputHeight()
    local inputWidth = effectManager:getInputWidth()

    local count = srt_data:count()
    for i = 0, count - 1 do
        local srt_line = srt_data:data(i)
        local startTime = srt_line:startTime()
        local endTime = srt_line:endTime()

        if endTime >= time and startTime <= time then
            -- print("time:", startTime, time, endTime)
            if i ~= nowCount or init_count > 0 then
                text2d:pushCommandGenerate(
                    "display_texture",
                    srt_line:text(),
                    srt_line:length(),
                    ptFontSize / inputHeight,
                    0,
                    linesWidth / inputWidth,
                    1.3,
                    1,
                    0,
                    1
                )
                nowCount = i
                init_count = init_count - 1
            end
            local showAlpha = 1.0

            if endTime - startTime > 2 * showTimeShort then
                local showTimeTmp = showTime
                if endTime - startTime < 2 * showTime then showTimeTmp = showTimeShort end
                if time - startTime < showTimeTmp then
                    showAlpha = (time - startTime) / showTimeTmp
                elseif endTime - time < showTimeTmp then
                    showAlpha = (endTime - time) / showTimeTmp
                end
            end
            ge:setUniformFloat("drawTextOnOrigin", 1, "showAlpha", showAlpha)

            local timeFromBegin = time - startTime
            timeFromBegin = timeFromBegin % totalKeyFrameDuration

            for j = 2, #keyFrameCenterPos do
                if timeFromBegin < keyFrameTime[j] then
                    local posX = getVal(
                        keyFrameTime[j - 1],
                        keyFrameTime[j],
                        timeFromBegin,
                        keyFrameCenterPos[j - 1][1],
                        keyFrameCenterPos[j][1]
                    )
                    local posY = getVal(
                        keyFrameTime[j - 1],
                        keyFrameTime[j],
                        timeFromBegin,
                        keyFrameCenterPos[j - 1][2],
                        keyFrameCenterPos[j][2]
                    )


                    local yOffset = (posY / normHeight * 1280 + (inputHeight - 1280) / 2.0) / inputHeight
                    posX = posX / normWidth / (720.0 / inputWidth) 
                    posY = yOffset

                    ge:setUniformVec2("drawTextOnOrigin", 1, "center", posX, posY)

                    break
                end
            end

            break
        end
    end
end

EventHandles = {
    handleEffectEvent = function(this, eventCode)

        if eventCode == 1 then
            if (initFlag) then return true end
            initFlag = true

            -- local bgm = this:getAudioManager()
            -- if (bgm) then
            --     bgm:setLoop(1)
            --     bgm:startPlay()
            -- end

            this:addTimer(3214349, EffectSdk.BEF_TIMER_EVENT_CIRCLE, 10)

            local feature = this:getFeature("text")
            if feature then
                local text2d = EffectSdk.castText2DFeature(feature)
                text2d:updateFontPath()
            end
        end
        return true
    end,

    handleTimerEvent = function(this, timerId, milliSeconds)
        if timerId == 3214349 then

            local feature = this:getFeature("text")
            if not feature then
                return
            end
            local text2d = EffectSdk.castText2DFeature(feature)
            local feature2 = this:getFeature(geFeaturePath)
            if not feature2 then
                return
            end
            local geFeature = EffectSdk.castGeneralEffectFeature(feature2)

            local effectManager = this:getEffectManager()
            if not effectManager then
                return
            end
            if effectManager:getFontStatus() then text2d:updateFontPath() end

            local time = effectManager:getMusicCurrentTime()
            -- local audio_effect = this:getAudioManager()
            -- local time = audio_effect:getCurrentPlayTime()

            if effectManager:getSRTStatus() then effectManager:swapSRTIndex() end
            local srt_data = effectManager:getSRTData()

            local inputHeight = effectManager:getInputHeight()
            local inputWidth = effectManager:getInputWidth()

            local yOffset = (0.1875 * 1280 + (inputHeight - 1280) / 2.0) / inputHeight
            geFeature:setUniformVec2("drawTextOnOrigin", 1, "u_pos", 0.08333, yOffset) --  [0.08333, 0.1875]
            if feature and feature2 and text2d and geFeature then print_line(this, text2d, geFeature, srt_data, time) end
        end

        return true
    end,

}
