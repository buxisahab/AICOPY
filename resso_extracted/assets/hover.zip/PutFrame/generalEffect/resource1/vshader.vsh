precision highp float;

attribute vec3 attPosition;
attribute vec2 attUV;

uniform int u_width;
uniform int u_height;
uniform float u_d_width_offset;
uniform float u_d_height_offset;
uniform float angle;

uniform vec2 u_pos;
uniform vec2 center;

varying highp vec2 textureCoordinate;

const float bias = 30.0;

void main() {

    vec2 pos = attPosition.xy; // -1 ~ 1

    //step1. scale
    vec2 scale = vec2( (float(u_width) + 2.0*bias) * u_d_width_offset, float(u_height) * u_d_height_offset);
    pos = pos * scale; // -width ~ width, -height ~ height  

    //step2. rotation
    float cosAngle = cos(angle);
    float sinAngle = sin(angle);
    mat2 ratio = mat2(720.0, 0.0, 0.0, 1280.0);
    mat2 ratio_inv = mat2(0.0013888889, 0.0, 0.0, 0.00078125);
    mat2 rotation = mat2(cosAngle, sinAngle, -sinAngle, cosAngle);
    pos = ratio_inv * rotation * ratio * pos;

    //step3. translate
#if 0
    vec2 topleftWant = u_pos * 2.0 - 1.0;
    vec2 centerWant = topleftWant + scale;
#else
    vec2 centerWant = center * 2.0 - 1.0;
#endif
    
    pos = pos + centerWant;


    gl_Position = vec4(pos, 0.0, 1.0);
    // textureCoordinate = attUV.xy;

    // textureCoordinate.x = uv.x + attUV.x * (uv.z - uv.x);
    // textureCoordinate.y = uv.y + attUV.y * (uv.w - uv.y);

    textureCoordinate = attUV * scale;
}

