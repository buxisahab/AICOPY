precision highp float;

uniform sampler2D u_text;
uniform sampler2D u_text_blur;

varying highp vec2 textureCoordinate;

uniform float showAlpha; // 0->1



void main() {

    float alpha = texture2D(u_text, textureCoordinate).r;
    float alphaBlur = texture2D(u_text_blur, textureCoordinate).r;
    float alphaMix = mix(alphaBlur, alpha, showAlpha);

    gl_FragColor = vec4(alphaMix*showAlpha);


}

