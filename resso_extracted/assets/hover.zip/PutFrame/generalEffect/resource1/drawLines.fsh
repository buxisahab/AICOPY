precision highp float;

varying vec2 textureCoordinate;
// uniform sampler2D inputImageTexture;
uniform sampler2D u_text;

uniform int u_width;
uniform int u_height;
uniform float u_d_width_offset;
uniform float u_d_height_offset;

const float bias = 30.0;

void main() {
    float width = float(u_width) * u_d_width_offset;
    float height = float(u_height) * u_d_height_offset;
    vec3 bgColor = vec3(0.0);
    vec3 fgColor = vec3(1.0);
    float alpha = 0.0;
    float biasNorm = bias*u_d_width_offset;
    if (textureCoordinate.x > biasNorm && textureCoordinate.x < width+biasNorm && textureCoordinate.y < height) {
        vec2 uv = textureCoordinate;
        uv.x -= biasNorm;
        uv = uv / vec2(width, height);
        alpha = texture2D(u_text, uv).a;
    }

    gl_FragColor = vec4(mix(bgColor, fgColor, alpha), 1.0);
    
}
