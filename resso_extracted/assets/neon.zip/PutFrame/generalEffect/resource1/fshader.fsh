precision highp float;

uniform sampler2D u_text;

varying highp vec2 textureCoordinate;
varying highp vec4 color;

uniform mat4 u_textInfo;

void main() {
    float alpha = texture2D(u_text, textureCoordinate).a;
    gl_FragColor = vec4(color.rgb * color.a, color.a) * alpha ;
}

