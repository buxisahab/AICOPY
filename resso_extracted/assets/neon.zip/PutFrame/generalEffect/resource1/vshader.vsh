precision highp float;

attribute vec3 attPosition;
attribute vec2 attUV;
attribute vec4 attColor;

uniform vec2 u_pos;
varying highp vec2 textureCoordinate;
varying highp vec4 color;

void main() {
    vec2 pos = u_pos + attPosition.xy;
    gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);
    textureCoordinate = attUV.xy;
    color = attColor;
}

