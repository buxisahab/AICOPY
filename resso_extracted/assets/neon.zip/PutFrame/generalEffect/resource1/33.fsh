precision mediump float;

uniform sampler2D inputImageTexture;
uniform sampler2D text_texture;
uniform float flicker;

varying highp vec2 textureCoordinate;

float blendAdd(float base, float blend) {
    return min(base+blend,1.0);
}

vec3 blendAdd(vec3 base, vec3 blend) {
    return min(base+blend,vec3(1.0));
}

vec3 blendFunc(vec3 base, vec3 blend, float opacity) {
    return (blendAdd(base, blend) * opacity + base * (1.0 - opacity));
}

void main()
{
    vec4 fgColor = texture2D(inputImageTexture, textureCoordinate);
    vec4 fontColor = texture2D(text_texture, textureCoordinate);
    // fgColor.a = fgColor.a * flicker;
    // fontColor.a = fontColor.a * flicker;

    // vec3 color = blendFunc(bgColor.rgb, clamp(fgColor.rgb * (1.0 / fgColor.a), 0.0, 1.0), 1.0 );

    // vec4 blendColor = vec4(bgColor.rgb * (1.0 - fgColor.a) + color.rgb * fgColor.a, 1.0);

    // gl_FragColor = vec4(fontColor.rgb * fontColor.a + blendColor.rgb * (1.0 - fontColor.a), fontColor.a);
    // gl_FragColor = vec4(fontColor.rgb * 0.7 + bgColor.rgb * 0.3, 1.0) * fontColor.a;
    gl_FragColor = fontColor + fgColor * (1.0 - fontColor.a) * 1.5;
}
