local initFlag = false
local nowCount = -1
local init_count = 2
local geFeaturePath = "PutFrame/"
local stickerFeaturePath = "2DStickerV3/"

local generalScale = 0.9

-- 2DV3
local width2DV3 = 720 * generalScale
local height2DV3 = 1280 * generalScale

local status = 0
local lyricsIndex = -1
local curLyricsStartLineIndex = 0
local lastLyricsLineIndex = 0
local heightLimit = 0.6
local moveEndIndex = -1
local realCostMoveAnimation = -1

local red = {1.0, 0.996, 1.0}
local green = {0.231372549, 0.99215686274, 1.0}
local blue = {0.549, 0.38823529411, 1.0} 
local animationDuration = {0.4, 0.05, 0.2}
local moveDuration = 0.3

local flickerNode = {1, 0.3, 0.8, 0.5, 1}
local flickerDuration = 1.0

local heightOffset = 0.0

function find_srt(srt_data, time)
    local count = srt_data:count()
    for i = 0, count - 1 do
        local srt_line = srt_data:data(i)
        if srt_line:endTime() >= time and srt_line:startTime() <= time then
            return i
        end
    end
    return -1
end

function computeEndIndex(charLayoutArray, startIndex, endIndex, textureHeight, displayHeight)
    local startCharLayout = charLayoutArray:getCharLayout(startIndex)
    local endCharLayout = charLayoutArray:getCharLayout(endIndex)
if startCharLayout == nil or endCharLayout == nil then
    return
end
    local diff = textureHeight * (endCharLayout.texture_bottom - startCharLayout.texture_top) / displayHeight
    if diff > heightLimit * 1280 / displayHeight then
        local endNeedHeight = textureHeight * (endCharLayout.texture_bottom - endCharLayout.texture_top) / displayHeight
        local lastIndex = -1

        for index=startIndex,endIndex - 1 do
            local tempCharLayout = charLayoutArray:getCharLayout(index)
            if tempCharLayout == nil then
                return
            end
            local tempHeight = textureHeight * (tempCharLayout.texture_bottom - startCharLayout.texture_top) / displayHeight
            if tempHeight >= endNeedHeight then
                lastIndex = index
                break
            end
        end

        if lastIndex == -1 then
            lastIndex = endIndex - 1
            -- EffectSdk.LOG_LEVEL(6, "error, endNeedHeight: "..endNeedHeight)
        end
        return lastIndex
    end

    return -1
end

function moveLine(ge, charLayoutArray, startIndex, endIndex, lastIndex, textureWidth, textureHeight, displayWidth, displayHeight, moveProgress)
    local mode = 4
    local vertexStep = 3
    local uvStep = 2
    local vertexList = EffectSdk.vectorp3()
    local uvList = EffectSdk.vectorp3()
    local indexList = EffectSdk.vectori()
    local colorAttList = EffectSdk.vectorf()

    local topCharLayout = charLayoutArray:getCharLayout(startIndex)
    local bottomCharLayout = charLayoutArray:getCharLayout(endIndex)

    if topCharLayout == nil or bottomCharLayout == nil then
        return
    end

    local translateDistance = textureHeight * (bottomCharLayout.texture_bottom - topCharLayout.texture_top) / displayHeight
    -- offsetY
    local offsetY = moveProgress * translateDistance
    local counter = 0
    for index=startIndex,lastIndex do
        local animationIndex = index % #animationDuration
        local charLayout = charLayoutArray:getCharLayout(index)
        if charLayout == nil then
            return
        end
        local line_uv_width = charLayout.texture_right - charLayout.texture_left
        local line_uv_height = charLayout.texture_bottom - charLayout.texture_top
        local top_offset = textureHeight * (charLayout.texture_top - topCharLayout.texture_top) / displayHeight + heightOffset
        local line_width = textureWidth * line_uv_width / displayWidth
        local line_height = textureHeight * line_uv_height / displayHeight

        local positionTop = top_offset - offsetY
        local positionBottom = line_height + top_offset - offsetY
        if positionTop > 0.0 or positionBottom > 0.0 then
            if positionTop < 0.0 then
                positionTop = 0.0
            end
            if positionBottom < 0.0 then
                positionBottom = 0.0
            end
            local position1 = EffectSdk.Vec3(0, positionTop, 0.0)
            vertexList:push_back(position1)
            local position2 = EffectSdk.Vec3(0, positionBottom, 0.0)
            vertexList:push_back(position2)
            local position3 = EffectSdk.Vec3(line_width, positionTop, 0.0)
            vertexList:push_back(position3)
            local position4 = EffectSdk.Vec3(line_width, positionBottom, 0.0)
            vertexList:push_back(position4)
    
            local textureTop = charLayout.texture_top
            if top_offset - offsetY < 0.0 then
                textureTop = charLayout.texture_top + (math.abs(top_offset - offsetY) / line_height) * line_uv_height
                if textureTop > charLayout.texture_bottom then
                    textureTop = charLayout.texture_bottom
                end
            end
            local uv1 = EffectSdk.Vec3(charLayout.texture_left,textureTop, 0.0)
            uvList:push_back(uv1)
            local uv2 = EffectSdk.Vec3(charLayout.texture_left,charLayout.texture_bottom, 0.0)
            uvList:push_back(uv2)
            local uv3 = EffectSdk.Vec3(charLayout.texture_right,textureTop, 0.0)
            uvList:push_back(uv3)
            local uv4 = EffectSdk.Vec3(charLayout.texture_right,charLayout.texture_bottom, 0.0)
            uvList:push_back(uv4)
     
            indexList:push_back(counter * 4 + 0)
            indexList:push_back(counter * 4 + 1)
            indexList:push_back(counter * 4 + 2)
            indexList:push_back(counter * 4 + 1)
            indexList:push_back(counter * 4 + 3)
            indexList:push_back(counter * 4 + 2)
    
            local alphaTop = 1.0
            if top_offset - offsetY < 0.0 then
               alphaTop = 0.0
            end

            for i=1,2 do
                colorAttList:push_back(red[animationIndex + 1])
                colorAttList:push_back(green[animationIndex + 1])
                colorAttList:push_back(blue[animationIndex + 1])
                colorAttList:push_back(alphaTop)
    
                colorAttList:push_back(red[animationIndex + 1])
                colorAttList:push_back(green[animationIndex + 1])
                colorAttList:push_back(blue[animationIndex + 1])
                colorAttList:push_back(1.0)
            end
            
            counter = counter + 1
        end
    end

    ge:setBrcData("text1", mode, vertexList, vertexStep, uvList, uvStep, indexList)
    ge:setBrcAttributeData("text1", "attColor", colorAttList)
end

function showLyrics(ge, charLayoutArray, startIndex, endIndex, textureWidth, textureHeight, displayWidth, displayHeight, realProgress)
    local mode = 4
    local vertexStep = 3
    local uvStep = 2
    local vertexList = EffectSdk.vectorp3()
    local uvList = EffectSdk.vectorp3()
    local indexList = EffectSdk.vectori()
    local colorAttList = EffectSdk.vectorf()

    local firstCharLayout = charLayoutArray:getCharLayout(startIndex)
    if firstCharLayout == nil then
        return
    end
    for index=startIndex,endIndex do
        local type = index / 100.0
        local animationIndex = index % #animationDuration
        local charLayout = charLayoutArray:getCharLayout(index)
        if firstCharLayout == nil then
            return
        end
        local line_uv_width = charLayout.texture_right - charLayout.texture_left
        local line_uv_height = charLayout.texture_bottom - charLayout.texture_top
        local top_offset = textureHeight * (charLayout.texture_top - firstCharLayout.texture_top) / displayHeight + heightOffset
        local line_width = textureWidth * line_uv_width / displayWidth
        local line_height = textureHeight * line_uv_height / displayHeight
        
        if index == endIndex then
            if animationIndex == 0 then
                -- 0.03 ~ 0 ~ -0.03 ~ 0
                local amplitudeX = 0.03 * math.cos(realProgress * math.pi * 3 / 2)
                local amplitudeY = amplitudeX * line_height / line_width 
                local position1 = EffectSdk.Vec3(0 + amplitudeX, top_offset + amplitudeY, type)
                vertexList:push_back(position1)
                local position2 = EffectSdk.Vec3(0 + amplitudeX, line_height + top_offset - amplitudeY, type)
                vertexList:push_back(position2)
                local position3 = EffectSdk.Vec3(line_width - amplitudeX, top_offset + amplitudeY, type)
                vertexList:push_back(position3)
                local position4 = EffectSdk.Vec3(line_width - amplitudeX, line_height + top_offset - amplitudeY, type)
                vertexList:push_back(position4)  
            else if animationIndex == 1 then
                    -- 0 ~ 1
                    local amplitudeY = math.sin(realProgress * math.pi / 2)
                    local position1 = EffectSdk.Vec3(0, line_height + top_offset - line_height * amplitudeY, type)
                    vertexList:push_back(position1)
                    local position2 = EffectSdk.Vec3(0, line_height + top_offset , type)
                    vertexList:push_back(position2)
                    local position3 = EffectSdk.Vec3(line_width, line_height + top_offset - line_height * amplitudeY, type)
                    vertexList:push_back(position3)
                    local position4 = EffectSdk.Vec3(line_width, line_height + top_offset , type)
                    vertexList:push_back(position4)  
                else
                    local position1 = EffectSdk.Vec3(0, top_offset, type)
                    vertexList:push_back(position1)
                    local position2 = EffectSdk.Vec3(0, line_height + top_offset, type)
                    vertexList:push_back(position2)
                    local position3 = EffectSdk.Vec3(line_width, top_offset, type)
                    vertexList:push_back(position3)
                    local position4 = EffectSdk.Vec3(line_width, line_height + top_offset, type)
                    vertexList:push_back(position4)
                end   
            end
        else
            local position1 = EffectSdk.Vec3(0, top_offset, type)
            vertexList:push_back(position1)
            local position2 = EffectSdk.Vec3(0, line_height + top_offset, type)
            vertexList:push_back(position2)
            local position3 = EffectSdk.Vec3(line_width, top_offset, type)
            vertexList:push_back(position3)
            local position4 = EffectSdk.Vec3(line_width, line_height + top_offset, type)
            vertexList:push_back(position4)
        end 
       
        local uv1 = EffectSdk.Vec3(charLayout.texture_left,charLayout.texture_top, 0.0)
        uvList:push_back(uv1)
        local uv2 = EffectSdk.Vec3(charLayout.texture_left,charLayout.texture_bottom, 0.0)
        uvList:push_back(uv2)
        local uv3 = EffectSdk.Vec3(charLayout.texture_right,charLayout.texture_top, 0.0)
        uvList:push_back(uv3)
        local uv4 = EffectSdk.Vec3(charLayout.texture_right,charLayout.texture_bottom, 0.0)
        uvList:push_back(uv4)

        indexList:push_back((index - startIndex) * 4 + 0)
        indexList:push_back((index - startIndex) * 4 + 1)
        indexList:push_back((index - startIndex) * 4 + 2)
        indexList:push_back((index - startIndex) * 4 + 1)
        indexList:push_back((index - startIndex) * 4 + 3)
        indexList:push_back((index - startIndex) * 4 + 2)

        if index == endIndex then
            if animationIndex == 2 then
                --  0 ~ 1
                -- local amplitude = math.sin(realProgress * math.pi / 2)
             
                for i=1,4 do
                    colorAttList:push_back(red[animationIndex + 1])
                    colorAttList:push_back(green[animationIndex + 1])
                    colorAttList:push_back(blue[animationIndex + 1])
                    colorAttList:push_back(1.0 * realProgress)
                end
            else
                for i=1,4 do
                    colorAttList:push_back(red[animationIndex + 1])
                    colorAttList:push_back(green[animationIndex + 1])
                    colorAttList:push_back(blue[animationIndex + 1])
                    colorAttList:push_back(1.0)
                end
            end 
        else
             for i=1,4 do
                colorAttList:push_back(red[animationIndex + 1])
                colorAttList:push_back(green[animationIndex + 1])
                colorAttList:push_back(blue[animationIndex + 1])
                colorAttList:push_back(1.0)
             end
        end
    end

    ge:setBrcData("text1", mode, vertexList, vertexStep, uvList, uvStep, indexList)
    ge:setBrcAttributeData("text1", "attColor", colorAttList)
end

function clearLyrics(ge)
        local mode = 4
        local vertexStep = 3
        local uvStep = 2
        local vertexList = EffectSdk.vectorp3()
        local uvList = EffectSdk.vectorp3()
        local indexList = EffectSdk.vectori()
        local colorAttList = EffectSdk.vectorf()
        for i=1,4 do
            colorAttList:push_back(0.0)
            colorAttList:push_back(0.0)
            colorAttList:push_back(0.0)
            colorAttList:push_back(0.0)
        end

        local position1 = EffectSdk.Vec3(0.0, 0.0, 0)
        vertexList:push_back(position1)
        local position2 = EffectSdk.Vec3(0.0, 1.0, 0)
        vertexList:push_back(position2)
        local position3 = EffectSdk.Vec3(1.0, 0.0, 0)
        vertexList:push_back(position3)
        local position4 = EffectSdk.Vec3(1.0, 1.0, 0)
        vertexList:push_back(position4)

        local uv1 = EffectSdk.Vec3(0.0, 0.0, 0.0)
        uvList:push_back(uv1)
        local uv2 = EffectSdk.Vec3(0.0, 1.0, 0.0)
        uvList:push_back(uv2)
        local uv3 = EffectSdk.Vec3(1.0, 0.0, 0.0)
        uvList:push_back(uv3)
        local uv4 = EffectSdk.Vec3(1.0, 1.0, 0.0)
        uvList:push_back(uv4)

        indexList:push_back(0)
        indexList:push_back(1)
        indexList:push_back(2)
        indexList:push_back(1)
        indexList:push_back(3)
        indexList:push_back(2)

        ge:setBrcData("text1", mode, vertexList, vertexStep, uvList, uvStep, indexList)
        ge:setBrcAttributeData("text1", "attColor", colorAttList)
        -- print("sunlei clear screen")
end

function print_line(this, effectManager, text2d, ge, time, srt_line, curIndex)
    local duration = srt_line:endTime() - srt_line:startTime()
    local progress = time - srt_line:startTime()

    local charLayoutArray = nil
    local count = 0

    if curIndex ~= nowCount or init_count > 0 then
        local text_layout = EffectSdk.BEFTextLayoutParam()
        text_layout.fontSize = 48 * effectManager:getInputWidth() / 720 * generalScale -- effectManager:getInputHeight() / 1280
        text_layout.letterSpacing = 0
        text_layout.lineWidth = 518.4 * effectManager:getInputWidth() / 720 * generalScale
        text_layout.lineSpacingMult  = 1
        text_layout.textAlign = 0
        text_layout.maxLine = 0
        text_layout.fontPath = text2d:getRootDir()
        text_layout.familyName = "NeonOne.otf"
        text_layout.fontStyle = 0
        text_layout.lineBreakMode = 0
        text_layout.textColor = 0
        text_layout.backColor = 0
        text_layout.strokeWidth = 0
    
        text2d:generateBitmapUTF32("display_texture", srt_line:text(), srt_line:length(), text_layout, EffectSdk.TEXT_BITMAP_NEON_ALPHA)
        nowCount = curIndex
        init_count = init_count - 1  
        

        charLayoutArray = text2d:getTextLayoutWithKey("display_texture")
        if charLayoutArray == nil then
            return
        end
        count = charLayoutArray:getCount()
        curLyricsStartLineIndex = math.floor(count * progress / duration)
    end


    local charLayoutArray = text2d:getTextLayoutWithKey("display_texture")
    if charLayoutArray == nil then
        return
    end
    local count = charLayoutArray:getCount()

    -- EffectSdk.LOG_LEVEL(6, "charLayout count: "..count)
    local lineDuration = duration / count
    -- local indexFloat = progress / lineDuration
    -- local index = indexFloat - indexFloat % 1
    local index = math.floor(progress / lineDuration)
    local lineProgress = progress - index * lineDuration
    local animationIndex = index % #animationDuration
    local rectf = effectManager:getRenderCacheSize("display_texture")
    local displayWidth = effectManager:getInputWidth()
    local displayHeight = effectManager:getInputHeight()
    local textureWidth = rectf.right * displayWidth
    local textureHeight = rectf.bottom * displayHeight
    heightOffset = (displayHeight / 1280.0 - 1.0) / 3.0

--    EffectSdk.LOG_LEVEL(6, "displayWidth: " .. displayWidth .. ", displayHeight: " .. displayHeight .. ", textureWidth: " .. textureWidth .. ", textureHeight: " .. textureHeight .. ", heightOffset: " .. heightOffset)
    if index ~= lastLyricsLineIndex then
        lastLyricsLineIndex = index
        lastLyricsLineIndex = index
        moveEndIndex = computeEndIndex(charLayoutArray, curLyricsStartLineIndex, index, textureHeight, displayHeight)
        -- EffectSdk.LOG_LEVEL(6, "lyricsIndex: "..lyricsIndex..", count:"..count..", curLyricsStartLineIndex: "..curLyricsStartLineIndex..", index:"..index..", moveEndIndex:"..moveEndIndex)
        if moveEndIndex ~= -1 then
            status = 1
        else
            status = 0
        end
    end

    if status == 0 then
        local realAnimationDuration = math.min(animationDuration[animationIndex + 1], lineDuration)
        local realProgress = lineProgress / realAnimationDuration
        if realProgress >= 1.0 then
            realProgress = 1.0
        else if realProgress < 0.0 then
            realProgress = 0.0
            end
        end

        showLyrics(ge, charLayoutArray, curLyricsStartLineIndex, index, textureWidth, textureHeight, displayWidth, displayHeight, realProgress)
    else if status == 1 then
            local realMoveDuration = math.min(moveDuration, lineDuration / 2)
            local moveProgress = lineProgress / realMoveDuration
            if moveProgress >= 0.0 and moveProgress <= 1.0 then
                -- EffectSdk.LOG_LEVEL(6,"lyricsIndex: "..lyricsIndex..", StartLineIndex: "..curLyricsStartLineIndex..", moveEndIndex: "..moveEndIndex..", moveProgress: "..moveProgress..", realMoveDuration: "..realMoveDuration)
                moveLine(ge, charLayoutArray, curLyricsStartLineIndex, moveEndIndex, index - 1, textureWidth, textureHeight, displayWidth, displayHeight, moveProgress)
                return
            end 
            status = 2
            curLyricsStartLineIndex = moveEndIndex + 1
            moveEndIndex = -1
            realCostMoveAnimation = lineProgress
        end
    end

    if status == 2 then
        local realAnimationDuration = math.min(animationDuration[animationIndex + 1], lineDuration - realCostMoveAnimation)
        local realProgress = (lineProgress - realCostMoveAnimation) / realAnimationDuration
        if realProgress >= 1.0 then
            realProgress = 1.0
        else if realProgress < 0.0 then
            realProgress = 0.0
            end
        end
        -- EffectSdk.LOG_LEVEL(6, "lyricsIndex: "..lyricsIndex..", StartLineIndex: "..curLyricsStartLineIndex..", index: "..index..", realProgress: "..realProgress)
        showLyrics(ge, charLayoutArray, curLyricsStartLineIndex, index, textureWidth, textureHeight, displayWidth, displayHeight, realProgress)   
    end
end

EventHandles =
{
    handleEffectEvent = function (this, eventCode)
        if (initFlag) then
            return true
        end
        initFlag = true
        handleNeon(this)
        this:addTimer(3214349, EffectSdk.BEF_TIMER_EVENT_CIRCLE, 10)
        -- local bgm = this:getAudioManager()
        -- if(bgm) then
        --     bgm:setLoop(1)
        --     bgm:startPlay()
        -- end
        local feature = this:getFeature("text")
        return true
    end,

    handleTimerEvent = function (this, timerId, milliSeconds)
        handleNeon(this)
        return true
    end,
}

function handleNeon(this)
    local feature = this:getFeature("text")
    if not feature then
        return
    end
    local text2d = EffectSdk.castText2DV2Feature(feature)
    local feature2 = this:getFeature(geFeaturePath)
    if not feature2 then
        return
    end
    local ge = EffectSdk.castGeneralEffectFeature(feature2)

    local effectManager = this:getEffectManager()

    if not effectManager then
        return
    end
    -- local audio_effect = this:getAudioManager()
    -- local time = audio_effect:getCurrentPlayTime()
    local time = effectManager:getMusicCurrentTime()

    if effectManager:getSRTStatus() then effectManager:swapSRTIndex() end
    local srt_data = effectManager:getSRTData()
    if srt_data == nil then
        return
    end

    handleAnimation(this)
    local index = find_srt(srt_data, time)
        if index ~= -1 then
            local srt_line = srt_data:data(index)
            if index ~= lyricsIndex then
                lyricsIndex = index
                curLyricsStartLineIndex = 0
                lastLyricsLineIndex = 0
                status = 0
            end
            
            print_line(this, effectManager, text2d, ge, time, srt_line, index)
        else 
            clearLyrics(ge)
    end
end

 function handleAnimation(this)
     local effectManager = this:getEffectManager()
     if not effectManager then
         return
     end
      local srt_data = effectManager:getSRTData()
     if srt_data == nil then 
        return 
     end
     local time = effectManager:getMusicCurrentTime()
     local index = find_srt(srt_data, time)
     displayStickerIndex(this, "entity", "s2", -1)
     displayStickerIndex(this, "entity", "s1", -1)
     if index == -1 then
        return
     end

     local srt_line = srt_data:data(index)

     local duration = srt_line:endTime() - srt_line:startTime()
     if index == 0 then
         local stickerIndex = currentStickerIndex(25, 0, 12, srt_line:startTime(), time, true)
          -- displayStickerIndex(this, "entity", "s2", -1)
          displayStickerIndex(this, "entity", "s2", -1)
        displayStickerIndex(this, "entity", "s1", stickerIndex)
       
     else
         if duration >= 0 and duration < 2.5 then
            -- displayStickerIndex(this, "entity", "s2", -1)
            displayStickerIndex(this, "entity", "s2", -1)
             displayStickerIndex(this, "entity", "s1", 12)
             
         else
             local flickerStartTime = srt_line:startTime() + (srt_line:endTime() - srt_line:startTime()) / 2.0
             if time < flickerStartTime then
                -- displayStickerIndex(this, "entity", "s2", -1)
                displayStickerIndex(this, "entity", "s2", -1)
                displayStickerIndex(this, "entity", "s1", 12)
             else 
                local stickerIndex = currentStickerIndex(25, 0, 21, flickerStartTime, time, true)
                displayStickerIndex(this, "entity", "s1", -1)
                displayStickerIndex(this, "entity", "s2", stickerIndex)
             end
             
         end
     end
 end

function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end
    if( v > maxValue) then
        return maxValue
    end
    return v
end

function currentStickerIndex(fps, stickerFromIndex, stickerToIndex, startTime, currentTime, shouldRemoveAfterCompletion)
     if currentTime < startTime then
         return -1
     end
     local stickerCount = stickerToIndex - stickerFromIndex + 1
     if currentTime > startTime + 1.0 / fps * stickerCount then
        if shouldRemoveAfterCompletion then
            return stickerToIndex
        else 
            return -1
        end
     end

     local timeOffset = currentTime - startTime
     local index = math.floor(timeOffset / (1.0 / fps)) + stickerFromIndex
     return clamp(index, stickerFromIndex, stickerToIndex)
 end


function displayStickerIndex(this, entityName, clipName, index)
    local feature = this:getFeature(stickerFeaturePath)
    if not feature then
        return
    end
    local feature2DV3 = EffectSdk.castSticker2DV3Feature(feature)
    local effectManager = this:getEffectManager()
    if effectManager then
        local width = effectManager:getInputWidth()
        local height = effectManager:getInputHeight()
        if feature2DV3 then
            local centerX = width2DV3 * 0.5 / width
            local centerY = height2DV3 * 0.5 / height
            centerX = 0.5
            centerY = 0.5
            local normWidthSticker = width2DV3 / width
            local normHeightSticker = height2DV3 / height
            feature2DV3:setVertices(
                entityName,
                clipName,
                0,
                centerX - normWidthSticker * 0.5,
                centerY - normHeightSticker * 0.5
            )
            feature2DV3:setVertices(
                entityName,
                clipName,
                1,
                centerX + normWidthSticker * 0.5,
                centerY - normHeightSticker * 0.5
            )
            feature2DV3:setVertices(
                entityName,
                clipName,
                2,
                centerX - normWidthSticker * 0.5,
                centerY + normHeightSticker * 0.5
            )
            feature2DV3:setVertices(
                entityName,
                clipName,
                3,
                centerX + normWidthSticker * 0.5,
                centerY + normHeightSticker * 0.5
            )
            feature2DV3:appearClip(entityName, clipName, false)
            feature2DV3:resumeClip(entityName, clipName, false)
            feature2DV3:resetClip(entityName, clipName)
            -- feature2DV3:playClip(entityName, clipName, -1, 0)
            
            if index ~= -1 then
                feature2DV3:seek(entityName, clipName, index)
                feature2DV3:appearClip(entityName, clipName, true)
            end

            -- feature2DV3:playClipFromTo(entityName, clipName, 3, 3, 0, false);
        end
    end
end
